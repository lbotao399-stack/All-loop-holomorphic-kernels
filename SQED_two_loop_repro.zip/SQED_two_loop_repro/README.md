# Massive SQED: exact two-loop obstruction

This bundle reproduces the finite obstruction calculation in the manuscript's field convention. It uses Python 3 and standard-library modules. All polynomial coefficients and matrix operations use `fractions.Fraction`.

## Run

From this directory:

```sh
python3 regenerate_quotient.py
python3 verify.py
python3 verify_compact_laurent.py
python3 verify_compact_obstruction.py
```

The programs print their results and save a JSON report beside the scripts.

`regenerate_quotient.py` constructs the finite monomial bases, their classical cycles, the massive-pair contraction, and all 932 boundary columns from the differential. Its exact ranks are 394 before and 395 after adjoining the obstruction. It also checks equality with the span of the stored columns and evaluates the independent 167-term functional on the regenerated columns.

`verify.py` reconstructs the one- and two-loop graph actions on the recorded cochains. It checks closure, the first correction equation, the second obstruction equation, the direct two-loop action, and the factored meson obstruction at the three rational parameter values recorded in `verification.json`. It recomputes ranks and the dual-functional certificate using the stored column data.

`verify_compact_laurent.py` checks the compact first correction and the displayed Q1 action coefficientwise over the Laurent polynomial ring in `m`, `y`, and `ig`, for both dotted spinor components. It expands the grouped manuscript formulas, matches their 24 and 19 contracted terms, reconstructs Q1 from the Wick engine, and verifies `Q0 O1 + Q1 O0 = 0`.

`verify_compact_obstruction.py` uses the compact manuscript correction in `Q2 O0 + Q1 O1`. It checks that its difference from the stored meson target belongs to the complete obstruction quotient, verifies the general-coupling transport coefficientwise, and evaluates the same dual functional on the new representative. Its exact value is `-16 (ig)^2 y^4/m^2`, with the two-loop factor suppressed.

## Interaction and elimination

The manuscript interaction is

```
I = ig c (gamma_+ beta^+ - gamma_- beta^-)
    + (m/2) gamma_s^2 + y gamma_s gamma_+ gamma_-.
```

The exact cotangent change of variables is

```
gamma_s' = gamma_s + (y/m) gamma_+ gamma_-,
beta^{+'} = beta^+ - (y/m) gamma_- beta^s,
beta^{-'} = beta^- - (y/m) gamma_+ beta^s.
```

It gives `Q0 beta^s = -m gamma_s'` and the light superpotential
`-y^2/(2m) (gamma_+ gamma_-)^2`. The code retains the quantum transfer through this contractible pair. In particular, it constructs `Q1_eff = pi D1 i` from the cubic theory when generating the first-correction boundary columns.

## Field and coefficient dictionary

| Code field | Manuscript field | U(1) charge | Parity | Field weight |
|---|---|---:|---:|---:|
| `x` | gamma_+ | 1 | 0 | 1 |
| `y` | gamma_- | -1 | 0 | 1 |
| `Bx` | beta^+ | -1 | 1 | 3 |
| `By` | beta^- | 1 | 1 | 3 |
| `s` | gamma_s | 0 | 0 | 2 |
| `Bs` | beta^s | 0 | 1 | 2 |
| `b0` | b | 0 | 0 | 4 |
| `c0` | c | 0 | 1 | 0 |

Parity one means odd. Odd factors anticommute. A factor `[field,r,s]` is the ordinary derivative `partial_(+dot+)^r partial_(+dot-)^s field`. Monomials are multiplied in their recorded order; no factorial is absorbed into the jets.

The code variable `k` is the literal coupling `ig`. The JSON coefficient rule is

```
coefficient * m^m_power * y^y_power * (ig)^ig_power * (64*pi^2)^(-order).
```

The code name `y` for the field gamma_- is distinct from the argument `y` denoting the superpotential coupling. The inverse BV pairing has positive gauge and negative matter signs, as implemented by `Current.wiedge`.

## Finite sectors

Each interaction has field weight four, while each BV contraction removes weight four. An n-loop fan has n+1 interactions and 2n+1 contractions, so Qn lowers field weight by 4n. Its two derivative totals increase by (n,n). The couplings and derivatives have field weight zero. The heavy-pair contraction preserves the grading.

The basis generator enumerates charge-zero monomials of fixed parity, field weight, and derivative totals. Undifferentiated c is omitted. Even jets can repeat; odd jets occur at most once. These constraints give complete finite sectors:

| Space | Weight | Derivative totals | Parity | Dimension |
|---|---:|---|---:|---:|
| Source | 14 | (1,0) | 1 | 33 |
| Source predecessors under Q0 | 14 | (1,0) | 0 | 33 |
| First corrections | 10 | (2,1) | 1 | 365 |
| Second primitives | 6 | (3,2) | 1 | 752 |

The source has 18 classical cycles and 17 boundaries. The first-correction space has 180 classical cycles. The quotient columns are the 752 Q0 images of second primitives together with the Q1_eff images of all 180 first-correction cycles. This covers every change in the chosen first correction by a classical cycle.

The target has a nonzero pairing with a rational functional that annihilates all 932 columns. After removing the common two-loop factor, this pairing equals `-16` at `m=y=ig=1`. The recorded coefficient transport gives `-16 (ig)^2 y^4/m^2` at general nonzero parameters. `verify.py` checks annihilation and target evaluation coefficientwise as Laurent polynomials in `m`, `y`, and `ig`.

## Files

- `engine.py`: exact supercommutative jet algebra, Wick contractions, and one- and two-loop Schwinger moments.
- `current_theory.py`: manuscript signs and massive-pair transfer.
- `regenerate_quotient.py`: complete finite basis and column reconstruction.
- `verify.py`: cochain identities and certificate checks.
- `current_cochains.json`: source, 240-term first correction, 770-term second cochain, and 36-term factored target.
- `compact_O1.json`, `compact_Q1.json`: the manuscript's compact correction and Q1 action, expressed as 24 and 19 ordered covariant contractions in the primed fields. The compact first correction expands to 147 ordinary-jet terms in the original fields.
- `compact_one_loop.py`, `grouped_formula_check.py`: component expansion and literal grouped manuscript formulas.
- `verify_compact_laurent.py`: coefficientwise generic-coupling verification of those formulas.
- `verify_compact_obstruction.py`: equality of their second-obstruction class with the certified target.
- `obstruction_quotient.json.gz`: 932 stored columns and the 167-term dual functional.
- `regeneration.json`, `verification.json`: successful check reports from this revision.
- `compact_laurent_verification.json`, `compact_obstruction_verification.json`: exact checks for the compact correction used in the manuscript.

The first correction in `current_cochains.json` is the canonical representative used to construct the stored second cochain. The manuscript displays a shorter first correction. Their difference is a Q0 cycle; both give the same class in the second-obstruction quotient. The stored 770-term second cochain accompanies the canonical first correction. The paper's equation for the compact choice is an equality of obstruction classes.

The engine evaluates Q1 and Q2. The scripts establish the displayed finite-sector two-loop obstruction; they do not search every charge sector or evaluate higher-loop graphs.
