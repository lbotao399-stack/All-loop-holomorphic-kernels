"""Exact Q0,Q1,Q2 in the fixed holomorphic prescription for abelian gauge + W.
Physical Qn=(64*pi^2)^(-n) times stored Qn. No coupling rescaling.
Arbitrary polynomial W, full three residual momenta, all input jets.
"""
from fractions import Fraction as F
from collections import defaultdict
from functools import lru_cache
from itertools import product,permutations,combinations
from math import factorial

class Theory:
 def __init__(self,charges,W):
  self.charges=charges;self.rank=len(next(iter(charges.values())))
  self.gs=tuple(charges);self.bs={g:'B'+g for g in self.gs}
  self.odd=set(self.bs.values())|{'c'+str(a) for a in range(self.rank)}
  self.fields=tuple(sorted(self.gs+tuple(self.bs.values())+tuple('b'+str(a) for a in range(self.rank))+tuple('c'+str(a) for a in range(self.rank))))
  self.partners={**self.bs,**{b:g for g,b in self.bs.items()},**{'b'+str(a):'c'+str(a) for a in range(self.rank)},**{'c'+str(a):'b'+str(a) for a in range(self.rank)}}
  self.W={tuple(sorted((g,0,0) for g in w)):F(c) for w,c in W.items()}
  self.vertices=[(tuple(g for g,r,s in w),c) for w,c in self.W.items()]
  for g,qs in charges.items():
   for a,q in enumerate(qs):
    if q:self.vertices.append(((self.bs[g],'c'+str(a),g),F(q)))
  self.base={}
  for g,qs in charges.items():
   self.base[g]=self.add(*(self.scale(self.mul(self.v('c'+str(a)),self.v(g)),q) for a,q in enumerate(qs)))
   self.base[self.bs[g]]=self.add(self.fd(self.W,g),*(self.scale(self.mul(self.v('c'+str(a)),self.v(self.bs[g])),-q) for a,q in enumerate(qs)))
  for a in range(self.rank):
   self.base['c'+str(a)]={};self.base['b'+str(a)]=self.add(*(self.scale(self.mul(self.v(self.bs[g]),self.v(g)),-qs[a]) for g,qs in charges.items()))
 def parity(self,u):return int(u[0] in self.odd)
 def canon(self,w):
  os=[u for u in w if self.parity(u)]
  if len(os)!=len(set(os)):return (),0
  sg=(-1)**sum(self.parity(a)*self.parity(b) for i,a in enumerate(w) for b in w[i+1:] if a>b)
  return tuple(sorted(w)),sg
 @staticmethod
 def add(*ps):
  out=defaultdict(F)
  for p in ps:
   for w,c in p.items():out[w]+=c
  return {w:c for w,c in out.items() if c}
 @staticmethod
 def scale(p,c):return {w:x*c for w,x in p.items() if x*c}
 def mul(self,*ps):
  out={():F(1)}
  for p in ps:
   new=defaultdict(F)
   for a,c in out.items():
    for b,d in p.items():
     w,s=self.canon(a+b)
     if s:new[w]+=s*c*d
   out={w:c for w,c in new.items() if c}
  return out
 @staticmethod
 def v(g,r=0,s=0):return {((g,r,s),):F(1)}
 def deriv(self,p,axis):
  out=defaultdict(F)
  for w,c in p.items():
   for i,u in enumerate(w):
    v=list(u);v[axis+1]+=1;k,s=self.canon(w[:i]+(tuple(v),)+w[i+1:])
    if s:out[k]+=s*c
  return {w:c for w,c in out.items() if c}
 def jet(self,p,r,s):
  for axis,num in enumerate((r,s)):
   for _ in range(num):p=self.deriv(p,axis)
  return p
 def fd(self,p,g):
  out=defaultdict(F)
  for w,c in p.items():
   for i,u in enumerate(w):
    if u==(g,0,0):out[w[:i]+w[i+1:]]+=c*(-1)**(int(g in self.odd)*sum(self.parity(x) for x in w[:i]))
  return {w:c for w,c in out.items() if c}
 @lru_cache(maxsize=2048)
 def q0field(self,u):return self.jet(self.base[u[0]],*u[1:])
 def q0(self,p):
  out={}
  for w,c in p.items():
   for i,u in enumerate(w):out=self.add(out,self.scale(self.mul({w[:i]:F(1)},self.q0field(u),{w[i+1:]:F(1)}),c*(-1)**sum(self.parity(x) for x in w[:i])))
  return out
 def widiff(self,p,var):
  out=defaultdict(F)
  for w,c in p.items():
   for i,u in enumerate(w):
    if u==var:out[w[:i]+w[i+1:]]+=c*(-1)**(int(var[1] in self.odd)*sum(x[1] in self.odd for x in w[:i]))
  return {w:c for w,c in out.items() if c}
 def wiedge(self,p,i,j,slot=None):
  out={}
  for a,b in self.partners.items():
   right=(j,b) if slot is None else (j,b,slot)
   out=self.add(out,self.widiff(self.widiff(p,right),(i,a)))
  return out
 @lru_cache(maxsize=4096)
 def wick(self,n,ns,sig):
  root=n+2
  choices=[[t for t in self.vertices if self.partners[ns[sig[v]]] in t[0]] for v in range(n+1)]
  result=defaultdict(F)
  for verts in product(*choices):
   initial=tuple((i,g) for i,(w,c) in enumerate(verts,1) for g in w)+tuple((root,g,k) for k,g in enumerate(ns))
   coefficient=F(1)
   for w,c in verts:coefficient*=c
   p={initial:coefficient};edges=[]
   for i in range(1,n+1):edges.extend([(i,i+1,None),(i,root,sig[i-1])])
   edges.append((n+1,root,sig[n]))
   for i,j,slot in reversed(edges):
    p=self.wiedge(p,i,j,slot)
    if not p:break
   for w,c in p.items():
    assert all(len(u)==2 and u[0]<root for u in w)
    residual=tuple(tuple(g for vertex,g in w if vertex==v) for v in range(1,n+2))
    result[residual]+=c
  return tuple((res,c) for res,c in result.items() if c)
 @lru_cache(maxsize=2048)
 def selected(self,n,w):
  out={};ns=tuple(u[0] for u in w)
  for sig in permutations(range(n+1)):
   coeffs=self.wick(n,ns,sig)
   if not coeffs:continue
   moments=graphmoment(n,tuple(w[i][1:] for i in sig))
   for res,c in coeffs:
    for jets,k in moments.items():
     if any(not ww and any(jj) for ww,jj in zip(res,jets)):continue
     polys=[self.jet(self.mul(*(self.v(g) for g in ww)),*jj) for ww,jj in zip(res,jets)]
     out=self.add(out,self.scale(self.mul(*polys),(-1)**n*2**(n-1)*c*k))
  return out
 def qn(self,n,p):
  out={}
  for w,c in p.items():
   for ids in combinations(range(len(w)),n+1):
    selected=tuple(w[i] for i in ids);result=self.selected(n,selected)
    if not result:continue
    sg=(-1)**sum(self.parity(w[i])*sum(self.parity(w[j]) for j in range(i) if j not in ids[:k]) for k,i in enumerate(ids))
    rest=tuple(w[i] for i in range(len(w)) if i not in ids)
    out=self.add(out,self.scale(self.mul(result,{rest:F(1)}),c*sg))
  return out
 @staticmethod
 def fmt(p):return [{'coefficient':str(c),'monomial':list(w)} for w,c in sorted(p.items())]

# Commuting momentum/parameter polynomial algebra. Four parameters a,b,u,v.
def padd(*ps):
 out=defaultdict(F)
 for p in ps:
  for a,c in p.items():out[a]+=c
 return {a:c for a,c in out.items() if c}
def pscale(p,c):return {a:b*c for a,b in p.items() if b*c}
def pmul(p,q):
 out=defaultdict(F)
 for a,c in p.items():
  for b,d in q.items():out[tuple(x+y for x,y in zip(a,b))]+=c*d
 return {a:c for a,c in out.items() if c}
@lru_cache(maxsize=1024)
def graphmoment(n,jets):
 assert n in (1,2)
 N=4+2*(n+1);one={(0,)*N:F(1)}
 def var(i):
  a=[0]*N;a[i]=1;return {tuple(a):F(1)}
 a,b,u,v=[var(i) for i in range(4)]
 lam=[[var(4+2*i+j) for j in range(2)] for i in range(n+1)]
 def minus(p):return padd(one,pscale(p,-1))
 def wedge(i,j):return padd(pmul(lam[i][0],lam[j][1]),pscale(pmul(lam[i][1],lam[j][0]),-1))
 if n==1:
  density=wedge(0,1)
  currents=[[padd(pmul(minus(u),lam[0][j]),pmul(v,lam[1][j])) for j in range(2)],
  [padd(pmul(u,lam[0][j]),pmul(minus(v),lam[1][j])) for j in range(2)]]
 else:
  density=pmul(b,pmul(padd(pmul(minus(u),wedge(0,1)),pmul(v,wedge(0,2))),padd(pmul(a,wedge(0,2)),wedge(1,2))))
  y23=[padd(pmul(u,padd(pmul(a,lam[0][j]),lam[1][j])),pscale(pmul(v,lam[2][j]),-1)) for j in range(2)]
  y12=[padd(pmul(pmul(a,b),lam[0][j]),pscale(pmul(minus(b),lam[1][j]),-1),pmul(minus(b),y23[j])) for j in range(2)]
  currents=[[padd(lam[0][j],pscale(y12[j],-1)) for j in range(2)],
   [padd(lam[1][j],y12[j],pscale(y23[j],-1)) for j in range(2)],
   [padd(lam[2][j],y23[j]) for j in range(2)]]
 p=density
 for i,jet in enumerate(jets):
  for j,num in enumerate(jet):
   for _ in range(num):p=pmul(p,currents[i][j])
 out=defaultdict(F)
 for ex,c in p.items():
  A,B,U,V=ex[:4];mom=F(factorial(U)*factorial(V),(A+1)*(B+1)*factorial(U+V+2))
  jj=tuple(tuple(ex[4+2*i:6+2*i]) for i in range(n+1));out[jj]+=c*mom
 return {j:c for j,c in out.items() if c}
