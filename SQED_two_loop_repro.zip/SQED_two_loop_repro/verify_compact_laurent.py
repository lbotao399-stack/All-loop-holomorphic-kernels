"""Coefficientwise generic-coupling verification of the manuscript's formulas."""
from compact_one_loop import *
from grouped_formula_check import grouped_first,grouped_q1
class Laurent:
    def __init__(self,p=0):
        self.p=dict(p.p) if isinstance(p,Laurent) else {e:F(c) for e,c in p.items() if c} if isinstance(p,dict) else {(0,0,0):F(p)} if p else {}
    def __add__(self,q):
        q=Laurent(q);p=dict(self.p)
        for e,c in q.p.items():p[e]=p.get(e,F(0))+c
        return Laurent(p)
    __radd__=__add__
    def __neg__(self):return Laurent({e:-c for e,c in self.p.items()})
    def __sub__(self,q):return self+-Laurent(q)
    def __rsub__(self,q):return Laurent(q)+-self
    def __mul__(self,q):
        q=Laurent(q);p={}
        for a,c in self.p.items():
            for b,d in q.p.items():
                e=tuple(x+y for x,y in zip(a,b));p[e]=p.get(e,F(0))+c*d
        return Laurent(p)
    __rmul__=__mul__
    def __pow__(self,n):
        if n<0:
            assert len(self.p)==1
            e,c=next(iter(self.p.items()))
            return Laurent({tuple(n*a for a in e):c**n})
        p=Laurent(1)
        for _ in range(n):p=p*self
        return p
    def __truediv__(self,q):return self*Laurent(q)**-1
    def __rtruediv__(self,q):return Laurent(q)*self**-1
    def __eq__(self,q):return self.p==Laurent(q).p
    def __bool__(self):return bool(self.p)
    def __repr__(self):return repr(self.p)

def symbolic_current(m,y,k):
    U=Current(F(1),F(1),F(1))
    U.W={tuple(sorted((g,0,0) for g in ('s','s'))):m/2,tuple(sorted((g,0,0) for g in ('s','x','y'))):y}
    U.vertices=[(('s','s'),m/2),(('s','x','y'),y),(('Bx','c0','x'),-k),(('By','c0','y'),k)]
    U.base['x']=U.scale(U.mul(U.v('c0'),U.v('x')),k)
    U.base['y']=U.scale(U.mul(U.v('c0'),U.v('y')),-k)
    for g,q in [('x',1),('y',-1),('s',0)]:
        U.base['B'+g]=U.add(U.scale(U.mul(U.v('c0'),U.v('B'+g)),-k*q),U.scale(U.fd(U.W,g),-1))
    U.base['b0']=U.scale(U.add(U.mul(U.v('Bx'),U.v('x')),U.scale(U.mul(U.v('By'),U.v('y')),-1)),k)
    return U

def main():
    m=Laurent({(1,0,0):1});y=Laurent({(0,1,0):1});k=Laurent({(0,0,1):1})
    U=symbolic_current(m,y,k)
    data=json.loads((SQ/'current_cochains.json').read_text())
    old=restored(data['canonical_UV_first'],m,y,k)
    frows=json.loads((HERE/'compact_O1.json').read_text());qrows=json.loads((HERE/'compact_Q1.json').read_text())
    reports=[]
    for axis in (0,1):
        source=restored(data['source'],m,y,k);oldaxis=old
        if axis:
            source=U.mul({tuple((g,s,r) for g,r,s in w):c for w,c in source.items()})
            oldaxis=U.mul({tuple((g,s,r) for g,r,s in w):-c for w,c in old.items()})
        first=grouped_first(U,m,y,k,axis);qfirst=grouped_q1(U,m,y,k,axis)
        assert first==contracted_terms(U,frows,m,y,k,axis)
        assert qfirst==contracted_terms(U,qrows,m,y,k,axis)
        assert qfirst==U.qn(1,source)
        assert not U.add(U.q0(first),qfirst)
        difference=U.add(first,U.scale(oldaxis,-1))
        assert not U.q0(difference)
        reports.append({'dot_a':axis,'grouped_O1':True,'grouped_Q1':True,'Q1_from_Wick_engine':True,'Q0O1_plus_Q1O0':True,'difference_Q0_closed':True,'coefficient_ring':'Q[m,m^-1,y,y^-1,ig,(ig)^-1]'})
    result={'all_passed':True,'symbolic_Laurent_coefficients':True,'checks':reports}
    (HERE/'compact_laurent_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
