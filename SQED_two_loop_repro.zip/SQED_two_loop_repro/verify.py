"""Exact SQED cochain verification in the manuscript's existing field convention."""
from pathlib import Path
import sys,gzip,json,time
from fractions import Fraction as F
from engine import Theory
HERE=Path(__file__).resolve().parent
D=json.loads((HERE/'current_cochains.json').read_text())
def parse(rows): return {tuple(tuple(u) for u in r['monomial']):F(r['coefficient']) for r in rows}
def restore(rows,n,m,y,k):
    return {tuple(tuple(u) for u in row['monomial']): F(row['coefficient'])*m**row['m_power']*y**row['y_power']*k**row['ig_power'] for row in rows}
from current_theory import Current

def contracted(U,a,b):
    return U.add(U.mul(U.jet(a,2,0),U.jet(b,0,2)),U.scale(U.mul(U.jet(a,1,1),U.jet(b,1,1)),-2),U.mul(U.jet(a,0,2),U.jet(b,2,0)))
def direct(U,m,y,k):
    x,yy,s,b,c,bp,bm,bs=[U.v(g) for g in ['x','y','s','b0','c0','Bx','By','Bs']]
    terms=[]
    terms.append(U.scale(U.mul(contracted(U,bp,c),U.add(bm,U.scale(U.mul(bs,x),-y/m))),k/3))
    terms.append(U.scale(U.mul(contracted(U,bm,c),U.add(bp,U.scale(U.mul(bs,yy),-y/m))),k/3))
    terms.append(U.scale(U.mul(U.add(contracted(U,bp,x),U.scale(contracted(U,bm,yy),-1)),x,yy),y*y/(3*m)))
    terms.append(U.mul(contracted(U,c,x),U.add(U.scale(U.mul(bs,bp),k*y/(3*m)),U.scale(U.mul(b,yy),y*y/m))))
    terms.append(U.mul(contracted(U,c,yy),U.add(U.scale(U.mul(bs,bm),k*y/(3*m)),U.scale(U.mul(b,x),-y*y/m))))
    terms.append(U.mul(contracted(U,s,x),U.add(U.scale(U.mul(bs,yy),-y*y/(3*m)),U.scale(bp,y/3))))
    terms.append(U.mul(contracted(U,s,yy),U.add(U.scale(U.mul(bs,x),y*y/(3*m)),U.scale(bm,-y/3))))
    terms.append(U.scale(U.mul(contracted(U,x,yy),U.add(U.mul(bp,x),U.scale(U.mul(bm,yy),-1))),-y*y/m))
    return U.scale(U.mul(U.add(*terms),U.v('c0',1,0)),k**3)

started=time.time();reports=[]
for m,y,k in [(F(1),F(1),F(1)),(F(3),F(2),F(2)),(F(-2),F(3),F(-3))]:
    U=Current(m,y,k)
    p=[restore(D[key],n,m,y,k) for n,key in [(0,'source'),(1,'canonical_UV_first'),(2,'canonical_UV_second'),(2,'canonical_target')]]
    source,first,second,target=p
    assert not U.q0(source)
    assert not U.add(U.qn(1,source),U.q0(first))
    q2=U.qn(2,source)
    assert q2==direct(U,m,y,k)
    assert U.add(q2,U.qn(1,first),U.q0(second))==target
    meson=U.mul(U.v('x'),U.v('y'))
    factored=U.scale(U.mul(U.jet(meson,1,0),contracted(U,meson,meson)),-2*k*k*y**4/m**2)
    assert target==factored
    assert U.q0(q2)
    assert not U.add(U.q0(q2),U.qn(1,U.qn(1,source)))
    reports.append({'m':str(m),'y':str(y),'ig':str(k),'closure':True,'first_equation':True,'second_equation':True,'direct_Q2_formula':True,'factored_target':True,'Q0Q2_nonzero':True,'direct_Q2_terms':len(q2)})
    print(reports[-1],flush=True)

# The functional is a separate exact nontriviality certificate.
Q=json.load(gzip.open(HERE/'obstruction_quotient.json.gz','rt'))
columns=[parse(rows) for rows in Q['secondary_columns']]
functional=parse(Q['dual_functional'])
def pair(a,p): return sum((a.get(w,F(0))*c for w,c in p.items()),F(0))
assert len(columns)==932 and len(functional)==167
assert all(pair(functional,c)==0 for c in columns)
target=restore(D['canonical_target'],2,F(1),F(1),F(1))
assert pair(functional,target)==-16
pivots={}
def insert(v):
    v=dict(v)
    while v:
        i=min(v)
        if i not in pivots:
            a=v[i];pivots[i]={w:c/a for w,c in v.items()};return
        a=v[i]
        for w,c in pivots[i].items():
            v[w]=v.get(w,F(0))-a*c
            if not v[w]:del v[w]
for col in columns:insert(col)
assert len(pivots)==394
insert(target)
assert len(pivots)==395
for m,y,k in [(F(3),F(2),F(2)),(F(-2),F(3),F(-3))]:
    ell={tuple(tuple(u) for u in row['monomial']):F(row['coefficient'])*m**row['m_power']*y**row['y_power']*k**row['ig_power'] for row in Q['dual_functional']}
    assert pair(ell,restore(D['canonical_target'],2,m,y,k))==-16*k*k*y**4/m**2
    # The coordinate transport acts diagonally on target monomials.
    for col in columns:
        transported={}
        for w,c in col.items():
            L=sum(u[0] in ('Bx','By','b0') for u in w);S=sum(u[0]=='s' for u in w);B=sum(u[0]=='Bs' for u in w)
            cg=sum(u[0]=='c0' for u in w);bg=sum(u[0]=='b0' for u in w)
            transported[w]=c*m**(-2+L+S)*y**(4-2*L-S-B)*k**(2+cg-bg)
        assert pair(ell,transported)==0
# Check the coupling transport coefficientwise as a Laurent polynomial.
ell_rows={tuple(tuple(u) for u in row['monomial']):row for row in Q['dual_functional']}
def laurent_pair(rows):
    result={}
    for row in rows:
        w=tuple(tuple(u) for u in row['monomial'])
        if w not in ell_rows:continue
        a=ell_rows[w]
        powers=tuple(a[key]+row[key] for key in ('m_power','y_power','ig_power'))
        result[powers]=result.get(powers,F(0))+F(a['coefficient'])*F(row['coefficient'])
    return {powers:c for powers,c in result.items() if c}
for col in columns:
    rows=[]
    for w,c in col.items():
        L=sum(u[0] in ('Bx','By','b0') for u in w);S=sum(u[0]=='s' for u in w);B=sum(u[0]=='Bs' for u in w)
        cg=sum(u[0]=='c0' for u in w);bg=sum(u[0]=='b0' for u in w)
        rows.append({'monomial':w,'coefficient':str(c),'m_power':-2+L+S,
                     'y_power':4-2*L-S-B,'ig_power':2+cg-bg})
    assert not laurent_pair(rows)
assert laurent_pair(D['canonical_target'])=={(-2,4,2):F(-16)}
# Extend the light functional to UV cochains through the classical projection.
# In original UV coordinates pi sends s to -(y/m)xy and every Bs jet to zero.
for m,y,k in [(F(1),F(1),F(1)),(F(3),F(2),F(2)),(F(-2),F(3),F(-3))]:
    U=Current(m,y,k)
    ell={tuple(tuple(u) for u in row['monomial']):F(row['coefficient'])*m**row['m_power']*y**row['y_power']*k**row['ig_power'] for row in Q['dual_functional']}
    def project(p):
        out={};meson=U.mul(U.v('x'),U.v('y'))
        for w,c in p.items():
            if any(g=='Bs' for g,r,s in w):continue
            out=U.add(out,U.scale(U.mul(*(U.scale(U.jet(meson,r,s),-y/m) if g=='s' else U.v(g,r,s) for g,r,s in w)),c))
        return out
    source=restore(D['source'],0,m,y,k);first=restore(D['canonical_UV_first'],1,m,y,k)
    assert pair(ell,project(U.add(U.qn(2,source),U.qn(1,first))))==-16*k*k*y**4/m**2
out={'all_passed':True,'current_convention_checks':reports,'rational_rank':394,'augmented_rational_rank':395,'dual_terms':167,'annihilated_columns':932,'dual_stripped_target_at_unit_parameters':'-16','dual_coupling_identity_coefficientwise':True,'seconds':time.time()-started}
(HERE/'verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(out,flush=True)
