from compact_one_loop import *

def grouped_first(U,m,y,k,axis):
    bp,bm,bs,b,c,x,z=[U.v(g) for g in ['Bx','By','Bs','b0','c0','x','y']]
    def d(p,a):return U.deriv(p,a)
    def a(p):return d(p,axis)
    out={}
    for j,kk,sg in [(0,1,1),(1,0,-1)]:
        term=U.mul(U.add(U.scale(U.mul(bp,bm),k*k),U.scale(U.mul(b,x,z),k*y*y/m)),
            U.add(U.mul(a(d(bp,j)),d(x,kk)),U.scale(U.mul(d(bp,j),a(d(x,kk))),-1),U.scale(U.mul(a(d(bm,j)),d(z,kk)),-1),U.mul(d(bm,j),a(d(z,kk)))))
        out=U.add(out,U.scale(term,F(2,3)*sg))
        term=U.mul(b,U.add(U.mul(U.add(U.mul(d(bp,j),bm),U.scale(U.mul(bp,d(bm,j)),-1)),a(d(c,kk))),U.scale(U.mul(U.add(U.mul(a(d(bp,j)),bm),U.scale(U.mul(bp,a(d(bm,j))),-1)),d(c,kk)),-1)))
        out=U.add(out,U.scale(term,F(2,3)*k*k*sg))
        term=U.mul(b,U.add(U.mul(bp,a(x)),U.mul(bm,a(z))),d(x,j),d(z,kk))
        out=U.add(out,U.scale(term,F(8,3)*k*y*y/m*sg))
        term=U.mul(b,U.add(U.mul(bp,z,d(x,j),a(d(x,kk))),U.scale(U.mul(bm,x,d(z,j),a(d(z,kk))),-1)))
        out=U.add(out,U.scale(term,F(4,3)*k*y*y/m*sg))
        term=U.mul(b,b,U.add(U.mul(d(c,j),U.add(U.mul(z,a(d(x,kk))),U.scale(U.mul(x,a(d(z,kk))),-1))),U.mul(a(d(c,j)),U.add(U.mul(x,d(z,kk)),U.scale(U.mul(z,d(x,kk)),-1))),U.scale(U.mul(a(c),d(x,j),d(z,kk)),15)))
        out=U.add(out,U.scale(term,F(1,3)*k*y*y/m*sg))
        term=U.add(U.mul(b,b,a(bs),d(c,j),d(c,kk)),U.scale(U.mul(b,d(bs,j),U.add(U.mul(bp,d(x,kk)),U.mul(bm,d(z,kk))),a(c)),-2))
        out=U.add(out,U.scale(term,k*k*y/m*sg))
    return embed(U,out,m,y)

def grouped_q1(U,m,y,k,axis):
    bp,bm,bs,b,c,x,z,s=[U.v(g) for g in ['Bx','By','Bs','b0','c0','x','y','s']]
    def d(p,a):return U.deriv(p,a)
    def a(p):return d(p,axis)
    out={};meson=U.mul(x,z)
    for j,kk,sg in [(0,1,1),(1,0,-1)]:
        term=U.add(U.mul(b,d(U.mul(bp,bm),j),d(c,kk)),U.scale(U.mul(d(bp,j),bp,bm,d(x,kk)),-1),U.mul(bp,d(bm,j),bm,d(z,kk)),U.scale(U.mul(d(bs,j),b,U.add(U.mul(bm,z),U.scale(U.mul(bp,x),-1)),d(c,kk)),y/m),U.scale(U.mul(d(bs,j),bp,bm,d(meson,kk)),-y/m))
        out=U.add(out,U.scale(U.mul(term,a(c)),2*k**3*sg))
        term=U.add(U.mul(b,b,d(c,j),d(s,kk)),U.scale(U.mul(b,U.add(U.mul(bp,d(s,j),d(x,kk)),U.mul(bm,d(s,j),d(z,kk)))),-1))
        out=U.add(out,U.scale(U.mul(term,a(c)),2*k*k*y*sg))
        term=U.add(U.scale(U.mul(b,b,d(c,j),d(meson,kk)),2),U.scale(U.mul(b,U.add(U.mul(bp,x),U.scale(U.mul(bm,z),-1)),d(x,j),d(z,kk)),3),U.mul(b,meson,U.add(U.mul(d(bp,j),d(x,kk)),U.mul(d(bm,j),d(z,kk)))),U.scale(U.mul(b,meson,d(bs,j),d(meson,kk)),y/m))
        out=U.add(out,U.scale(U.mul(term,a(c)),-2*k*k*y*y/m*sg))
    return embed(U,out,m,y)

if __name__=='__main__':
    frows=json.loads((HERE/'compact_O1.json').read_text());qrows=json.loads((HERE/'compact_Q1.json').read_text())
    for m,y,k in [(F(1),F(1),F(1)),(F(3),F(2),F(2)),(F(-2),F(3),F(-3))]:
        for axis in (0,1):
            U=Current(m,y,k)
            assert grouped_first(U,m,y,k,axis)==contracted_terms(U,frows,m,y,k,axis),'O1'
            assert grouped_q1(U,m,y,k,axis)==contracted_terms(U,qrows,m,y,k,axis),'Q1'
    print('Grouped formulas match all 24+19 contracted terms for both components at three exact parameter points.')
