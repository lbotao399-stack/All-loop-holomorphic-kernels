"""Manuscript fields, pairings, and exact elimination of the massive pair.

Stored Qn omits the common (64*pi**2)**(-n). No jet factorials are used.
"""
from fractions import Fraction as F
from functools import lru_cache
from engine import Theory


class Current(Theory):
    def __init__(self, m, y, k, light=False):
        m, y, k = F(m), F(y), F(k)
        charges = {'x': (1,), 'y': (-1,)}
        if light:
            W = {('x', 'x', 'y', 'y'): -y*y/(2*m)}
        else:
            charges['s'] = (0,)
            W = {('s', 's'): m/2, ('s', 'x', 'y'): y}
        super().__init__(charges, W)
        self.vertices = [(w, c*(-k if 'c0' in w else 1)) for w,c in self.vertices]
        for g, qs in charges.items():
            q = qs[0]
            self.base[g] = self.scale(self.mul(self.v('c0'), self.v(g)), k*q)
            self.base['B'+g] = self.add(
                self.scale(self.mul(self.v('c0'), self.v('B'+g)), -k*q),
                self.scale(self.fd(self.W, g), -1))
        self.base['b0'] = self.scale(self.add(
            self.mul(self.v('Bx'), self.v('x')),
            self.scale(self.mul(self.v('By'), self.v('y')), -1)), k)

    def wiedge(self, p, i, j, slot=None):
        out = {}
        for a,b in self.partners.items():
            right = (j,b) if slot is None else (j,b,slot)
            out = self.add(out, self.scale(self.widiff(self.widiff(p,right),(i,a)),
                                         1 if a in ('b0','c0') else -1))
        return out


class Transfer:
    """Exact cotangent change of variables followed by the heavy-pair contraction."""
    def __init__(self, m=1, y=1, k=1):
        self.m, self.y, self.k = F(m), F(y), F(k)
        self.U = Current(m,y,k)
        self.V = Current(m,y,k,light=True)
        U = self.U
        a = self.y/self.m
        self.to_uv = {g: U.v(g) for g in U.fields}
        self.to_uv['s'] = U.add(U.v('s'), U.scale(U.mul(U.v('x'),U.v('y')), a))
        self.to_uv['Bx'] = U.add(U.v('Bx'), U.scale(U.mul(U.v('y'),U.v('Bs')), -a))
        self.to_uv['By'] = U.add(U.v('By'), U.scale(U.mul(U.v('x'),U.v('Bs')), -a))
        self.from_uv = {g: U.v(g) for g in U.fields}
        self.from_uv['s'] = U.add(U.v('s'), U.scale(U.mul(U.v('x'),U.v('y')), -a))
        self.from_uv['Bx'] = U.add(U.v('Bx'), U.scale(U.mul(U.v('y'),U.v('Bs')), a))
        self.from_uv['By'] = U.add(U.v('By'), U.scale(U.mul(U.v('x'),U.v('Bs')), a))

    def substitute(self, p, table):
        U = self.U
        return U.add(*(U.scale(U.mul(*(U.jet(table[g],r,s) for g,r,s in w)),c)
                       for w,c in p.items()))

    def embed(self, p):
        return self.substitute(p, self.to_uv)

    def transformed(self, n, p):
        initial = self.embed(p)
        result = self.U.q0(initial) if n == 0 else self.U.qn(n, initial)
        return self.substitute(result, self.from_uv)

    @staticmethod
    def project(p):
        return {w:c for w,c in p.items() if all(g not in ('s','Bs') for g,r,s in w)}

    def homotopy(self, p):
        U = self.U
        out = {}
        for w,c in p.items():
            heavy = sum(g in ('s','Bs') for g,r,s in w)
            if heavy == 0:
                continue
            for i,(g,r,s) in enumerate(w):
                if g == 's':
                    out = U.add(out, U.scale(U.mul(U.v('Bs',r,s),
                                   {w[:i]+w[i+1:]:F(1)}), -c/(self.m*heavy)))
        return out

    @lru_cache(maxsize=4096)
    def eff1_word(self, w):
        return self.project(self.transformed(1, {w:F(1)}))

    def eff1(self, p):
        U = self.U
        return U.add(*(U.scale(self.eff1_word(w),c) for w,c in p.items()))

    def eff2(self, p):
        U = self.U
        return self.project(U.add(self.transformed(2,p), U.scale(
            self.transformed(1,self.homotopy(self.transformed(1,p))), -1)))
