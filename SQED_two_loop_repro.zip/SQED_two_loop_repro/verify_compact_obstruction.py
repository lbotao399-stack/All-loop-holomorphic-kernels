"""The manuscript's compact O1 gives the certified second-obstruction class."""
from verify_compact_laurent import Laurent, symbolic_current
from compact_one_loop import restored, project, HERE
from grouped_formula_check import grouped_first
from regenerate_quotient import Span, parse
from fractions import Fraction as F
import gzip
import json
import time


def main():
    started = time.time()
    m,y,k = [Laurent({tuple(int(i==j) for i in range(3)):1}) for j in range(3)]
    U = symbolic_current(m,y,k)
    D = json.loads((HERE/'current_cochains.json').read_text())
    Q = json.load(gzip.open(HERE/'obstruction_quotient.json.gz','rt'))
    source = restored(D['source'],m,y,k)
    first = grouped_first(U,m,y,k,0)
    oldfirst = restored(D['canonical_UV_first'],m,y,k)
    meson_target = restored(D['canonical_target'],m,y,k)
    assert not U.add(U.q0(first),U.qn(1,source))
    assert not U.q0(U.add(first,U.scale(oldfirst,-1)))
    obstruction = project(U,U.add(U.qn(2,source),U.qn(1,first)),m,y)
    difference = U.add(obstruction,U.scale(meson_target,-1))

    # This diagonal map carries the unit-parameter target complex to its
    # generic counterpart. Check the displayed cochain under that map.
    unit_difference = {}
    for w,c in difference.items():
        L = sum(g in ('Bx','By','b0') for g,r,s in w)
        assert all(g not in ('s','Bs') for g,r,s in w)
        cg = sum(g=='c0' for g,r,s in w)
        bg = sum(g=='b0' for g,r,s in w)
        expected = (-2+L,4-2*L,2+cg-bg)
        assert set(c.p) == {expected}
        unit_difference[w] = c.p[expected]
    span = Span()
    for rows in Q['secondary_columns']:
        span.insert(parse(rows))
    assert span.rank == 394
    assert not span.reduce(unit_difference)[0]

    # Pair the new representative with the same functional, keeping every
    # coupling as a formal Laurent variable through the Wick computation.
    ell = restored(Q['dual_functional'],m,y,k)
    value = sum((ell.get(w,Laurent(0))*c for w,c in obstruction.items()),Laurent(0))
    assert value == -16*k*k*y**4/m**2
    zero = sum((ell.get(w,Laurent(0))*c for w,c in difference.items()),Laurent(0))
    assert not zero
    result = {'all_passed':True,'compact_first_primitive_used':True,
              'new_minus_canonical_O1_is_Q0_closed':True,
              'new_obstruction_same_quotient_class':True,
              'quotient_membership_at_unit_parameters':True,
              'generic_transport_checked_coefficientwise':True,
              'generic_dual_value':'-16*(ig)^2*y^4/m^2',
              'projected_obstruction_terms':len(obstruction),
              'projected_difference_terms':len(difference),
              'rational_quotient_rank':span.rank,'seconds':time.time()-started}
    (HERE/'compact_obstruction_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__ == '__main__':
    main()
