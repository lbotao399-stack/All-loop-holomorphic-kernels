"""Regenerate the complete finite sectors and obstruction quotient over Q.

Run with Python 3. No third-party dependencies, external paths, or network.
The stored columns are used only for an independent equality-of-spans check.
"""
from pathlib import Path
from fractions import Fraction as F
import gzip
import json
import time
from current_theory import Transfer

HERE = Path(__file__).resolve().parent


class Span:
    def __init__(self):
        self.p = {}

    def reduce(self,v,combo=None):
        v,co = dict(v), {} if combo is None else dict(combo)
        while v:
            i = min(v)
            if i not in self.p:
                return v,co
            w,ww = self.p[i]
            a = v[i]
            for k,b in w.items():
                v[k] = v.get(k,F(0))-a*b
                if not v[k]: del v[k]
            for k,b in ww.items():
                co[k] = co.get(k,F(0))-a*b
                if not co[k]: del co[k]
        return v,co

    def insert(self,v,combo=None):
        v,co = self.reduce(v,combo)
        if not v:
            return False,co
        a = v[min(v)]
        self.p[min(v)] = ({k:b/a for k,b in v.items()}, {k:b/a for k,b in co.items()})
        return True,co

    @property
    def rank(self):
        return len(self.p)


def basis(T,W,R,S,parity):
    """All charge-zero jet monomials in the relative complex (no bare c)."""
    if min(W,R,S) < 0:
        return []
    wt = {'x':1,'y':1,'Bx':3,'By':3,'b0':4,'c0':0}
    qs = {'x':1,'y':-1,'Bx':-1,'By':1,'b0':0,'c0':0}
    vs = tuple(sorted((g,r,s) for g in T.fields for r in range(R+1)
                      for s in range(S+1) if not(g == 'c0' and r+s == 0)))
    out = []
    def rec(i,w,R,S,p,charge,word):
        if w == 0 and R == 0 and S == 0:
            if p == 0 and charge == 0:
                out.append(word)
            return
        for j in range(i,len(vs)):
            u = vs[j]
            g,r,s = u
            if wt[g] > w or r > R or s > S:
                continue
            rec(j+T.parity(u), w-wt[g], R-r, S-s,
                (p+T.parity(u))%2, charge+qs[g], word+(u,))
    rec(0,W,R,S,parity,0,())
    return out


def parse(rows):
    return {tuple(tuple(u) for u in r['monomial']):F(r['coefficient']) for r in rows}


def pair(a,p):
    return sum((a.get(w,F(0))*c for w,c in p.items()),F(0))


def main():
    started = time.time()
    T = Transfer()
    U,V = T.U,T.V
    D = json.loads((HERE/'current_cochains.json').read_text())
    source,first,second,target = [parse(D[k]) for k in (
        'source','canonical_UV_first','canonical_UV_second','canonical_target')]
    for g in U.fields:
        p = U.v(g)
        assert T.substitute(T.embed(p),T.from_uv) == p
        expected = U.scale(U.v('s'),-1) if g == 'Bs' else {} if g == 's' else V.q0(p)
        assert T.transformed(0,p) == expected
    for p in [source,first,second]+[U.mul(U.v('s',r,s),U.v('Bs',s,r),U.v('Bx'))
                                  for r,s in [(0,0),(1,0),(0,1)]]:
        p = T.substitute(p,T.from_uv)
        assert U.add(T.transformed(0,T.homotopy(p)),T.homotopy(T.transformed(0,p))) == U.add(p,U.scale(T.project(p),-1))
    print('Current-field classical contraction: PASS', flush=True)

    first_basis = basis(V,10,2,1,1)
    second_basis = basis(V,6,3,2,1)
    first_polynomials = [{w:F(1)} for w in first_basis]
    image = Span()
    cycles = []
    for i,p in enumerate(first_polynomials):
        fresh,co = image.insert(V.q0(p),{i:F(1)})
        if not fresh:
            z = V.add(*(V.scale(first_polynomials[j],c) for j,c in co.items()))
            assert not V.q0(z)
            cycles.append(z)
    columns = [V.q0({w:F(1)}) for w in second_basis]+[T.eff1(z) for z in cycles]
    quotient = Span()
    for c in columns:
        assert not V.q0(c)
        quotient.insert(c)
    assert (len(first_basis),len(cycles),len(second_basis),len(columns),quotient.rank) == (365,180,752,932,394)
    print('Regenerated all 932 quotient columns, rank 394: PASS', flush=True)

    Q = json.load(gzip.open(HERE/'obstruction_quotient.json.gz','rt'))
    stored = [parse(c) for c in Q['secondary_columns']]
    stored_span = Span()
    for c in stored:
        assert not quotient.reduce(c)[0]
        stored_span.insert(c)
    assert stored_span.rank == quotient.rank
    ell = parse(Q['dual_functional'])
    assert all(pair(ell,c) == 0 for c in columns)
    assert pair(ell,target) == -16
    projected = T.project(T.substitute(U.add(U.qn(2,source),U.qn(1,first)),T.from_uv))
    assert pair(ell,projected) == -16
    assert not quotient.reduce(U.add(projected,U.scale(target,-1)))[0]
    assert quotient.insert(target)[0] and quotient.rank == 395

    src,prev = basis(V,14,1,0,1),basis(V,14,1,0,0)
    src_image,boundaries = Span(),Span()
    for w in src:
        src_image.insert(V.q0({w:F(1)}))
    for w in prev:
        boundaries.insert(V.q0({w:F(1)}))
    light = T.project(T.substitute(source,T.from_uv))
    assert not V.q0(light)
    assert boundaries.reduce(light)[0]
    assert (len(src),len(prev),len(src)-src_image.rank,boundaries.rank) == (33,33,18,17)
    out = {'all_passed':True,'convention':'manuscript fields and pairings',
           'source_space':33,'source_cycles':18,'source_boundaries':17,
           'first_primitives':365,'first_cycles':180,'second_primitives':752,
           'regenerated_columns':932,'rational_rank':394,'augmented_rational_rank':395,
           'stored_and_regenerated_column_spans_equal':True,'dual_terms':len(ell),
           'dual_target':'-16','seconds':time.time()-started}
    (HERE/'regeneration.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2),flush=True)


if __name__ == '__main__':
    main()
