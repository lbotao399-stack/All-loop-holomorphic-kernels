"""Exact component checks of the displayed covariant massive-SQED formulas.
Only Python's standard library is required. Physical O1 and Q1 include
one common factor (64*pi^2)^(-1), suppressed in these rational polynomials.
The JSON slots record multiplication order; free/contract1/contract2 place
partial_(+dot a), partial_(+dot b), partial_+^(dot b), respectively.
"""
from pathlib import Path
from fractions import Fraction as F
import json, sys
HERE=Path(__file__).resolve().parent
SQ=HERE if (HERE/'engine.py').exists() else HERE.parent/'sqed'
sys.path.insert(0,str(SQ))
from engine import Theory

class Current(Theory):
    def __init__(self,m,y,k):
        super().__init__({'x':(1,),'y':(-1,),'s':(0,)},{('s','s'):m/2,('s','x','y'):y})
        self.vertices=[(w,c*(-k if 'c0' in w else 1)) for w,c in self.vertices]
        self.base['x']=self.scale(self.mul(self.v('c0'),self.v('x')),k)
        self.base['y']=self.scale(self.mul(self.v('c0'),self.v('y')),-k)
        for g,q in [('x',1),('y',-1),('s',0)]:
            self.base['B'+g]=self.add(self.scale(self.mul(self.v('c0'),self.v('B'+g)),-k*q),self.scale(self.fd(self.W,g),-1))
        self.base['b0']=self.scale(self.add(self.mul(self.v('Bx'),self.v('x')),self.scale(self.mul(self.v('By'),self.v('y')),-1)),k)
    def wiedge(self,p,i,j,slot=None):
        out={}
        for a,b in self.partners.items():
            right=(j,b) if slot is None else (j,b,slot)
            out=self.add(out,self.scale(self.widiff(self.widiff(p,right),(i,a)),1 if a in ('b0','c0') else -1))
        return out

def substitute(U,p,table):
    out={}
    for w,c in p.items():
        out=U.add(out,U.scale(U.mul(*(U.jet(table[g],r,s) for g,r,s in w)),c))
    return out

def embed(U,p,m,y):
    table={g:U.v(g) for g in U.fields}
    table['s']=U.add(U.v('s'),U.scale(U.mul(U.v('x'),U.v('y')),y/m))
    table['Bx']=U.add(U.v('Bx'),U.scale(U.mul(U.v('y'),U.v('Bs')),-y/m))
    table['By']=U.add(U.v('By'),U.scale(U.mul(U.v('x'),U.v('Bs')),-y/m))
    return substitute(U,p,table)

def project(U,p,m,y):
    table={g:U.v(g) for g in U.fields}
    table['s']=U.scale(U.mul(U.v('x'),U.v('y')),-y/m)
    table['Bs']={}
    return substitute(U,p,table)

def powers(fs):
    light=sum(g in ('Bx','By','b0') for g in fs)
    neutral=fs.count('s');bs=fs.count('Bs')
    return -3+light+neutral,6-2*light-neutral-bs,2+fs.count('c0')-fs.count('b0')

def contracted_terms(U,rows,m,y,k,axis):
    out={}
    for row in rows:
        fs=row['fields'];mp,yp,kp=powers(fs)
        coefficient=F(row['coefficient'])*m**mp*y**yp*k**kp
        p={}
        for a,b,sign in [(0,1,1),(1,0,-1)]:
            jets=[[0,0] for _ in fs]
            jets[row['free']][axis]+=1
            jets[row['contract1']][a]+=1
            jets[row['contract2']][b]+=1
            p=U.add(p,U.scale(U.mul(*(U.v(g,*j) for g,j in zip(fs,jets))),sign))
        out=U.add(out,U.scale(p,coefficient))
    return embed(U,out,m,y)

def restored(rows,m,y,k):
    return {tuple(tuple(u) for u in row['monomial']):F(row['coefficient'])*m**row['m_power']*y**row['y_power']*k**row['ig_power'] for row in rows}

def main():
    data=json.loads((SQ/'current_cochains.json').read_text())
    frows=json.loads((HERE/'compact_O1.json').read_text())
    qrows=json.loads((HERE/'compact_Q1.json').read_text())
    report=[];expanded={}
    for m,y,k in [(F(1),F(1),F(1)),(F(3),F(2),F(2)),(F(-2),F(3),F(-3))]:
        U=Current(m,y,k)
        old=restored(data['canonical_UV_first'],m,y,k)
        for axis in (0,1):
            source=restored(data['source'],m,y,k)
            oldaxis=old
            if axis:
                source={tuple((g,s,r) for g,r,s in w):c for w,c in source.items()}
                source=U.mul(source)
                oldaxis=U.mul({tuple((g,s,r) for g,r,s in w):-c for w,c in old.items()})
            first=contracted_terms(U,frows,m,y,k,axis)
            qfirst=contracted_terms(U,qrows,m,y,k,axis)
            assert U.qn(1,source)==qfirst
            assert not U.add(U.q0(first),qfirst)
            difference=U.add(first,U.scale(oldaxis,-1))
            assert not U.q0(difference)
            light=project(U,difference,m,y)
            assert not project(U,U.q0(difference),m,y)
            report.append({'m':str(m),'y':str(y),'ig':str(k),'dot_a':axis,'Q1_formula':True,'one_loop_closure':True,'difference_is_Q0_cycle':True,'original_O1_terms':len(first),'projected_difference_terms':len(light)})
            if (m,y,k,axis)==(F(1),F(1),F(1),0):
                expanded={'new_first':U.fmt(first),'old_first_difference':U.fmt(difference),'projected_difference':U.fmt(light),'Q1_source':U.fmt(qfirst)}
    (HERE/'compact_one_loop_verification.json').write_text(json.dumps({'all_passed':True,'checks':report,'coefficient_basis':'Every monomial has unique coupling powers given by powers(fs); the unit-parameter identities therefore extend coefficientwise.'},indent=2)+'\n')
    (HERE/'compact_one_loop_expanded.json').write_text(json.dumps(expanded,indent=2)+'\n')
    print(json.dumps({'all_passed':True,'checks':report},indent=2))
if __name__=='__main__':main()
